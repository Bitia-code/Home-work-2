﻿using System;
using Microsoft.Data.SqlClient;

namespace Home_work_2
{

    class Book
    {
        string connectionstring = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=\"Library Management System\";Integrated Security=True;";


        public void AddBook()
        {
            Console.Write("Enter Title: ");
            string title = Console.ReadLine();
            Console.Write("Enter Author: ");
            string author = Console.ReadLine();
            SqlConnection connection = new SqlConnection(connectionstring);

            string query = $"insert into Book(Title, Author, IsIssued) values('" + title + "', '" + author + "', 'true')";
            SqlCommand cmd = new SqlCommand(query, connection);
            connection.Open();
            int insertedRows = cmd.ExecuteNonQuery();
            if (insertedRows >= 1)
            {
                Console.Write("add successfuly");
            }
            else
            {
                Console.Write("failed");
            }
            connection.Close();
        }

        public void updatebook()
        {

            Console.Write("enter author");
            string author = Console.ReadLine();
            Console.Write("enter title");
            string title = Console.ReadLine();
            SqlConnection connection = new SqlConnection(connectionstring);

            string query = $"update Book set Title = '{title}' where Author = '{author}'";
            SqlCommand cmd = new SqlCommand(query, connection);
            connection.Open();
            int updatedRows = cmd.ExecuteNonQuery();
            connection.Close();
        }
        public void deleteBook()
        {
            Console.Write("enter title");
            string title = Console.ReadLine();
            SqlConnection connection = new SqlConnection(connectionstring);
            string query = $"delete  from Book where  Title = '{title}'";
            SqlCommand cmd = new SqlCommand(query, connection);
            connection.Open();
            int deletedRows = cmd.ExecuteNonQuery();
            connection.Close();
        }
        public void DispalyBook()
        {
            SqlConnection connection = new SqlConnection(connectionstring);
            string query = "select * from Book";
            SqlCommand cmd = new SqlCommand(query, connection);
            connection.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                Console.WriteLine($"{dr[0]},{dr[1]},{dr[2]},{dr[3]}");
            }
            connection.Close();
        }

    }

    class Member
    {
        string connectionstring = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=\"Library Management System\";Integrated Security=True;";

        public void addMember()
        {
            Console.WriteLine("Enter the name of Member");
            string name = Console.ReadLine();
            Console.WriteLine("Enter the CNIC of Member");
            string CNIC = Console.ReadLine();
            SqlConnection connection = new SqlConnection(connectionstring);

            string query = $"insert into Member(Name,CNIC) values('" + name + "', '" + CNIC + "')";
            SqlCommand cmd = new SqlCommand(query, connection);
            connection.Open();
            int insertedRrow = cmd.ExecuteNonQuery();
            if (insertedRrow >= 1)
            {
                Console.WriteLine("add succcessfuly");
            }
            else
            {
                Console.WriteLine("failed");
            }
            connection.Close();
        }

        public void updateMember()
        {
            Console.WriteLine("Enter the name of Member");
            string name = Console.ReadLine();
            Console.WriteLine("Enter the CNIC of Member");
            string CNIC = Console.ReadLine();

            SqlConnection connection = new SqlConnection(connectionstring);
            string query = $"update Member set CNIC = '{CNIC}' where Name = '{name}'";
            SqlCommand cmd = new SqlCommand(query, connection);
            connection.Open();
            int insertedRrow = cmd.ExecuteNonQuery();
            if (insertedRrow >= 1)
            {
                Console.WriteLine("update succcessfuly");
            }
            else
            {
                Console.WriteLine("failed");
            }
            connection.Close();
        }

        public void deleteMember()
        {
            Console.Write("enter Name");
            string name = Console.ReadLine();

            SqlConnection connection = new SqlConnection(connectionstring);

            string query = $"delete  from Member where  Name = '{name}'";
            SqlCommand cmd = new SqlCommand(query, connection);
            connection.Open();
            int deletedRows = cmd.ExecuteNonQuery();
            if (deletedRows >= 1)
            {
                Console.WriteLine("delete succcessfuly");
            }
            else
            {
                Console.WriteLine("failed");
            }

            connection.Close();
        }

        public void DispalyMenber()
        {
            SqlConnection connection = new SqlConnection(connectionstring);
            string query = "select * from Member";
            SqlCommand cmd = new SqlCommand(query, connection);
            connection.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                Console.WriteLine($"{dr[0]},{dr[1]},{dr[2]}");
            }
            connection.Close();
        }
    }
    class BorrowedBooks
    {
        string connectionstring = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=\"Library Management System\";Integrated Security=True;";

        public void BorrowBook()
        {
            Console.Write("Enter Member CNIC: ");
            string CNIC = Console.ReadLine();
            Console.Write("Enter Book ID: ");
            int bookID = int.Parse(Console.ReadLine());
            SqlConnection connection = new SqlConnection(connectionstring);

            string query = $"select from Member WHERE CNIC = '{CNIC}' " +
                                "select from Book WHERE BookID = '{bookID}' AND IsIssued = 0";
            SqlCommand cmd = new SqlCommand(query, connection);
            connection.Open();
            int insertedRrow = cmd.ExecuteNonQuery();
            connection.Close();


            string insertquery = $"insert into BorrowedBooks(MemberCNIC, BookID) values('" + CNIC + "', '" + bookID + "')";
            SqlCommand insertcmd = new SqlCommand(insertquery, connection);
            connection.Open();
            int RrowAffected = insertcmd.ExecuteNonQuery();
            if (RrowAffected >= 1)
            {
                Console.WriteLine("add succcessfuly");
            }
            else
            {
                Console.WriteLine("failed");
            }
            connection.Close();
        }

        public void ReturnBook()
        {
            Console.Write("Enter Borrow ID: ");
            int borrowID = int.Parse(Console.ReadLine());
            SqlConnection connection = new SqlConnection(connectionstring);

            string query = $"delete  from BorrowedBooks where  BorrowID = '{borrowID}'";
            SqlCommand cmd = new SqlCommand(query, connection);
            connection.Open();
            int deletedRows = cmd.ExecuteNonQuery();
            if (deletedRows >= 1)
            {
                Console.WriteLine("delete succcessfuly");
            }
            else
            {
                Console.WriteLine("failed");
            }

            connection.Close();
        }

        public void DispalyBorrowedBooks()
        {
            SqlConnection connection = new SqlConnection(connectionstring);
            string query = "select * from BorrowedBooks";
            SqlCommand cmd = new SqlCommand(query, connection);
            connection.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                Console.WriteLine($"{dr[0]},{dr[1]},{dr[2]}");
            }
            connection.Close();
        }
    }



    class Program
    {
        static void Main()
        {
            Book book = new Book();
            Member member = new Member();
            BorrowedBooks borrowedBooks = new BorrowedBooks();

            while (true)
            {
                Console.WriteLine("\nLibrary Management System");
                Console.WriteLine("1. Add Book");
                Console.WriteLine("2. Update Book");
                Console.WriteLine("3. Delete Book");
                Console.WriteLine("4. Display Books");
                Console.WriteLine("5. Add Member");
                Console.WriteLine("6. Update Member");
                Console.WriteLine("7. Delete Member");
                Console.WriteLine("8. Display Members");
                Console.WriteLine("9. Borrow Book");
                Console.WriteLine("10. Return Book");
                Console.WriteLine("11. Display Borrowed Books");
                Console.WriteLine("0. Exit");
                Console.Write("Enter your choice: ");

                int choice;
                if (!int.TryParse(Console.ReadLine(), out choice))
                {
                    Console.WriteLine("Invalid input. Please enter a valid option.");
                    continue;
                }

                switch (choice)
                {
                    case 1:
                        book.AddBook();
                        break;
                    case 2:
                        book.updatebook();
                        break;
                    case 3:
                        book.deleteBook();
                        break;
                    case 4:
                        book.DispalyBook();
                        break;
                    case 5:
                        member.addMember();
                        break;
                    case 6:
                        member.updateMember();
                        break;
                    case 7:
                        member.deleteMember();
                        break;
                    case 8:
                        member.DispalyMenber();
                        break;
                    case 9:
                        borrowedBooks.BorrowBook();
                        break;
                    case 10:
                        borrowedBooks.ReturnBook();
                        break;
                    case 11:
                        borrowedBooks.DispalyBorrowedBooks();
                        break;
                    case 0:
                        Console.WriteLine("Exiting program...");
                        return;
                    default:
                        Console.WriteLine("Invalid choice. Please select a valid option.");
                        break;
                }
            }
        }
    }
}






